from django.shortcuts import render, HttpResponse, redirect
from .models import *
def index(request):
    return render(request, 'post/index.html', { 'posts': Post.objects.all()})

def create_post(request):
    context = {
    'new_post' : Post.objects.create(post_content=request.POST['post_content'])
    }
    print(context)
    return render(request, 'post/post.html', context)